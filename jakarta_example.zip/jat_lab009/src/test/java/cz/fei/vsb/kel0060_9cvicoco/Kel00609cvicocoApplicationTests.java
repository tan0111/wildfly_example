package cz.fei.vsb.kel0060_9cvicoco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Kel00609cvicocoApplicationTests {

	@Test
	void contextLoads() {
	}

}
