package cz.fei.vsb.jat_lab009;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jat_lab009Application {

	public static void main(String[] args) {
		SpringApplication.run(Jat_lab009Application.class, args);
	}

}
