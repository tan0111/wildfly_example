package cz.fei.vsb.jat_lab009;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(securedEnabled = true)
public class SecurityConfig {


    @Autowired
    public void init(AuthenticationManagerBuilder builder) {
        builder.authenticationProvider(new AuthenticationProvider() {
            @Override
            public boolean supports(Class<?> authentication) {
                return authentication.equals(UsernamePasswordAuthenticationToken.class);
            }

            @Override
            public Authentication authenticate(Authentication authentication) throws AuthenticationException {
                String name = authentication.getName();
                String passwd = authentication.getCredentials().toString(); 

                if (name.matches("[A-Z].*") && passwd.matches("[0-9]+")) {
                    List<GrantedAuthority> grantedAuths = new ArrayList<>();

                    if (name.contains("s")) {
                        grantedAuths.add(new SimpleGrantedAuthority("ROLE_STUDENT"));
                    }
                    if (name.contains("t")) {
                        grantedAuths.add(new SimpleGrantedAuthority("ROLE_TEACHER"));
                    }

                    return new UsernamePasswordAuthenticationToken(name, passwd, grantedAuths);
                }

                return null;
            }

        });
    }

    

    
    @Bean
    public PasswordEncoder passwordEncoder() {
        return PasswordEncoderFactories.createDelegatingPasswordEncoder();
    }
    
    
    
    
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        return http.authorizeHttpRequests(request -> request
                .anyRequest().authenticated() 
            )
            .httpBasic(Customizer.withDefaults()) 
            .formLogin(form -> form
        			.loginPage("/login")
        			.permitAll()
        		)
            .build();
    }

//    .formLogin(Customizer.withDefaults()) 
}