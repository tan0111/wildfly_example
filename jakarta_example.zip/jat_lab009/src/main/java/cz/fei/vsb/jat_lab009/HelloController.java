package cz.fei.vsb.jat_lab009;

import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {

	@GetMapping("/hello")
	public String Hello() {
		return "hello";
	}
	
	@Secured("ROLE_STUDENT")
	@GetMapping("/securedStudentHello")
	public String studentHello() {
		return "cao";
	}
	
	@Secured("ROLE_TEACHER")
	@GetMapping("/securedTeacherHello")
	public String teacherHello() {
		return "good morning";
	}
	
	
//	@GetMapping("/login")
//	public String login() {
//		return "login";
//	}
}
