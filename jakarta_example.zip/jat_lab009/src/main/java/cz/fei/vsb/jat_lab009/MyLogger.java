package cz.fei.vsb.jat_lab009;

import org.apache.juli.logging.LogFactory;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Before;

public class MyLogger {

	@Before("execution(* cz.fei.vsb.jat_lab009.HelloController.*(..))")
	public void doLog(JoinPoint joinPoint) {
		LogFactory.getLog(getClass()).info("execute method: " + joinPoint.getSignature().getName());
	     
        System.out.println("Before method: " + joinPoint.getSignature().getName());
    
	
	
	}
}
